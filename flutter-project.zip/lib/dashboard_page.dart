import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'publik_chat.dart';
import 'webtoapk_page.dart';

// ─── Palette ──────────────────────────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF060F0A);
  static const surface   = Color(0xFF0C1E14);
  static const card      = Color(0xFF102418);
  static const border    = Color(0xFF1A3D2A);
  static const borderLit = Color(0xFF1E4A35);

  static const red        = Color(0xFF0D6B3E);
  static const redMid     = Color(0xFF15803D);
  static const redLight   = Color(0xFF22C55E);
  static const redFrost   = Color(0xFF86EFAC);

  static const green     = Color(0xFF22C55E);
  static const amber     = Color(0xFFF59E0B);
  static const blue      = Color(0xFF1B6FBD);

  static const text      = Color(0xFFE2EDF9);
  static const textSub   = Color(0xFF7A9BBF);
  static const textDim   = Color(0xFF3A5470);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [redMid, redLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':     return const Color(0xFFF59E0B);
    case 'moderator': return const Color(0xFFF59E0B);
    case 'partner':   return const Color(0xFFF59E0B);
    case 'admin':     return const Color(0xFFEF4444);
    case 'reseller':  return const Color(0xFF22C55E);
    case 'vip':       return const Color(0xFFA78BFA);
    default:          return _C.redLight;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':     return Icons.workspace_premium_rounded;
    case 'moderator': return Icons.workspace_premium_rounded;
    case 'partner':   return Icons.workspace_premium_rounded;
    case 'admin':     return Icons.admin_panel_settings_rounded;
    case 'reseller':  return Icons.storefront_rounded;
    case 'vip':       return Icons.star_rounded;
    default:          return Icons.person_rounded;
  }
}

// ─── Slide route helper ───────────────────────────────────────────────────────
Route _slideRoute(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, anim, __, child) => SlideTransition(
      position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
          .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
      child: child,
    ),
  );
}

// ─── Popular Cities ───────────────────────────────────────────────────────────
const _popularCities = [
  'jakarta', 'bandung', 'surabaya', 'jogja', 'semarang',
  'medan', 'makassar', 'bali', 'malang', 'palembang',
  'depok', 'bekasi', 'tangerang', 'bogor', 'lampung',
  'ponorogo', 'madura', 'cirebon', 'solo', 'balikpapan',
];

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  List<Map<String, dynamic>> get quickActions => [
  {
    "title": "Manage Sender",
    "subtitle": "Kelola WhatsApp sender",
    "icon": Icons.wifi_tethering_error_rounded,
    "color": const Color(0xff22c55e),
    "onTap": () {
      Navigator.push(
        context,
        _slideRoute(
          BugSenderPage(
            sessionKey: sessionKey,
            username: username,
            role: role,
          ),
        ),
      );
    },
  },
  {
  "title": "Public Chat",
  "subtitle": "Chat Global User Apps",
  "icon": Icons.forum_rounded,
  "color": const Color(0xffff9800),
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        CommunityPage(
          username: username,
          role: role,
        ),
      ),
    );
  },
},
 {
  "title": "Web To APK",
  "subtitle": "Build website menjadi APK",
  "icon": Icons.android_rounded,
  "color": const Color(0xff22c55e),
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        WebToApkPage(),
      ),
    );
  },
},
  {
    "title": "Telegram",
    "subtitle": "Join Qaxer Channel",
    "icon": FontAwesomeIcons.telegram,
    "color": const Color(0xff2AABEE),
    "onTap": () {
      _openUrl("https://t.me/Fionacantikwoe");
    },
  },
];
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listBugGroup, listDoos;
  late List<dynamic> newsList;
  
  late WebSocketChannel channel;
  String androidId    = 'unknown';
  File?  _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex      = 0;
  Widget _body       = const SizedBox();
  int onlineUsers    = 0;
  int activeConns    = 0;

  // ── Animation controllers ────────────────────────────────────────────────
  late AnimationController _bgCtrl;
  late AnimationController _pageCtrl;
  late AnimationController _drawerHeaderCtrl;

  late Animation<double> _pageFade;
  late Animation<Offset>  _pageSlide;

  // News carousel
  final PageController _newsPageCtrl = PageController(viewportFraction: 0.88);
  int _newsPage = 0;
  final PageController _quickCtrl =
    PageController(viewportFraction: 0.92);

int _quickIndex = 0;

  // ==========================
  // NEWS / SHOLAT / CUACA
  // ==========================
  int _homeTab = 0;

  String selectedCity = "jakarta";

  
  bool loadingPrayer = false;
  bool prayerLoading = false;
  bool prayerExpanded = false;
  bool loadingDoa = true;

  
  Map<String, dynamic>? prayerData;
  Map<String, dynamic>? doaData;


  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listBugGroup     = widget.listBugGroup;
    listDoos    = widget.listDoos;
    newsList    = widget.news;
    selectedCity = "jakarta";
  


    // Bg orbit
    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 20),
    )..repeat();

    // Page transition
    _pageCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );
    _pageFade  = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
        .animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));

    // Drawer header
    _drawerHeaderCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 700),
    );

    _body = _newsPage_();
    _pageCtrl.forward();

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();

    
    _fetchPrayer();
    _fetchDoa();
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _drawerHeaderCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    super.dispose();
  }

  // ── Init helpers ──────────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    channel = WebSocketChannel.connect(
        Uri.parse('http://lutpexzofficialpanel.pterodactylxcz.my.id:2051')); //ganti ke server wajib
    channel.sink.add(jsonEncode({
      'type': 'validate', 'key': sessionKey, 'androidId': androidId,
    }));
    channel.sink.add(jsonEncode({'type': 'stats'}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        final reason = data['reason'];
        _handleInvalidSession(reason == 'androidIdMismatch'
            ? 'Akun ini login di perangkat lain.'
            : 'Sesi tidak valid. Silakan login ulang.');
      }
      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers  = data['onlineUsers']       ?? 0;
          activeConns  = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  // ── Weather & Prayer ──────────────────────────────────────────────────────
  

  Future<void> _fetchPrayer() async {
  try {
    setState(() => loadingPrayer = true);

    final res = await http.get(
      Uri.parse(
        "http://lutpexzofficialpanel.pterodactylxcz.my.id:2051/api/prayertime?username=$username&key=$sessionKey",
      ),
    );

    final json = jsonDecode(res.body);

    if (json["success"] == true) {
      setState(() {
        prayerData = json["result"];
        selectedCity = json["city"];
      });
    }
  } catch (_) {}

  if (mounted) {
    setState(() => loadingPrayer = false);
  }
}
  
  Future<void> searchCity(String city) async {
  if (city.trim().isEmpty) return;

  selectedCity = city.trim();

  await Future.wait([
    
    _fetchPrayer(),
  ]);

  setState(() {});
}

Future<void> _fetchDoa() async {
  try {
    final res = await http.get(
      Uri.parse("http://lutpexzofficialpanel.pterodactylxcz.my.id:2051/api/doa"),
    );

    if (res.statusCode == 200) {
      final json = jsonDecode(res.body);

      if (mounted) {
        setState(() {
          doaData = json;
          loadingDoa = false;
        });
      }
    }
  } catch (_) {
    if (mounted) {
      setState(() => loadingDoa = false);
    }
  }
}

  // ── Change City — Search Bottom Sheet ────────────────────────────────────
  Future<void> _changeCity(String city) async {
  try {
    setState(() {
      loadingPrayer = true;
    });

    final res = await http.get(
      Uri.parse(
        "http://lutpexzofficialpanel.pterodactylxcz.my.id:2051/api/prayertime"
        "?username=$username"
        "&key=$sessionKey"
        "&city=${Uri.encodeComponent(city)}",
      ),
    );

    final json = jsonDecode(res.body);

    if (json["success"] == true && mounted) {
      setState(() {
        prayerData = json["result"];
        selectedCity = json["city"];
      });
    }
  } catch (e) {
    debugPrint("Prayer fetch error: $e");
  } finally {
    if (mounted) {
      setState(() {
        loadingPrayer = false;
      });
    }
  }
}
  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    _showSystemDialog(
      title: 'Sesi Berakhir',
      message: message,
      icon: Icons.lock_outline_rounded,
      color: _C.red,
      onOk: () => Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (_) => false,
      ),
    );
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _navigate(Widget page) {
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    switch (index) {
      case 0:
        _navigate(_newsPage_());
        break;
      case 1:
        _navigate(HomePage(
          username: username, password: password,
          listBug: listBug, listBugGroup: listBugGroup, role: role,
          expiredDate: expiredDate, sessionKey: sessionKey,
        ));
        break;
      case 2:
        _navigate(InfoPage(sessionKey: sessionKey));
        break;
      case 3:
        _navigate(ToolsPage(
            sessionKey: sessionKey, userRole: role, listDoos: listDoos));
        break;
      case 4:
        _navigate(CommunityPage(
          username: username, role: role));
        break;
    }
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1: _navigate(SellerPage(keyToken: sessionKey)); break;
      case 2: _navigate(AdminPage(sessionKey: sessionKey)); break;
      case 3: _navigate(OwnerPage(sessionKey: sessionKey, username: username)); break;
    }
  }

  // ── System dialog ─────────────────────────────────────────────────────────
  void _showSystemDialog({
    required String title,
    required String message,
    required IconData icon,
    required Color color,
    VoidCallback? onOk,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.transparent,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: color.withOpacity(0.15), blurRadius: 50)],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(height: 16),
            Text(title,
                style: const TextStyle(
                    color: _C.text, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: _C.textSub, fontSize: 13, height: 1.5)),
            const SizedBox(height: 24),
            _GradBtn(label: 'OK', fullWidth: true, onTap: () {
              Navigator.pop(ctx);
              onOk?.call();
            }),
          ]),
        ),
      ),
    );
  }

  // ── NEWS PAGE ─────────────────────────────────────────────────────────────
  Widget _newsPage_() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),

          // ===== TAB NEWS / SHOLAT / CUACA ====

          const SizedBox(height: 18),

          // ===================== NEWS =====================
          if (newsList.isNotEmpty) ...[
            SizedBox(
              height: 210,
              child: PageView.builder(
                controller: _newsPageCtrl,
                onPageChanged: (i) => setState(() => _newsPage = i),
                itemCount: newsList.length,
                itemBuilder: (_, i) {
                  final item = newsList[i];
                  final isActive = i == _newsPage;
                  return AnimatedScale(
                    scale: isActive ? 1.0 : 0.94,
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOutCubic,
                    child: _NewsCard(
                      item: item,
                      isActive: isActive,
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),

            // Dot indicators
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(newsList.length, (i) {
                final active = i == _newsPage;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: active ? 20 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: active ? _C.redMid : _C.border,
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            ),
          ],

          const SizedBox(height: 22),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: DashboardProfileCard(
    username: username,
    role: role,
    expired: expiredDate,
    profileImage: _profileImage,
  ),
),
          const SizedBox(height: 24),

          // ── Quick actions header ──────────────────────────────────────────
          Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [

      const Text(
        "Quick Actions",
        style: TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),

      const SizedBox(height: 4),

      Text(
        "Menu Langsung",
        style: TextStyle(
          color: Colors.white.withOpacity(.6),
        ),
      ),

      const SizedBox(height: 18),

      SizedBox(
        height: 185,
        child: PageView.builder(
          controller: _quickCtrl,
          itemCount: quickActions.length,
          onPageChanged: (i) {
            setState(() {
              _quickIndex = i;
            });
          },
          itemBuilder: (_, i) {
            return _QuickActionModernCard(
              data: quickActions[i],
            );
          },
        ),
      ),

      const SizedBox(height: 14),

      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(
          quickActions.length,
          (i) => AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            width: _quickIndex == i ? 22 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: _quickIndex == i
                  ? Colors.white
                  : Colors.white24,
              borderRadius: BorderRadius.circular(20),
            ),
          ),
        ),
      ),
    ],
  ),
),
          const SizedBox(height: 14),

          
        
          const SizedBox(height: 14),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: _PrayerCard(
    data: prayerData,
    loading: loadingPrayer,
    city: selectedCity,
    onChange: _changeCity,
    
  ),
),

const SizedBox(height: 18),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: _DoaCard(
    data: doaData,
    loading: loadingDoa,
  ),
),

const SizedBox(height: 24),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: const _QaxerTeamCard(),
),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ── Scaffold ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _pageFade,
              child: SlideTransition(
                position: _pageSlide,
                child: _body,
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ── AppBar ────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 0,
      leading: Builder(builder: (ctx) => _MenuBtn(onTap: () => Scaffold.of(ctx).openDrawer())),
      title: Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Halo, $username 👋',
              style: const TextStyle(
                color: _C.text,
                fontSize: 16,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            Row(children: [
              Container(
                width: 6, height: 6,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: _C.green,
                  boxShadow: [BoxShadow(color: Color(0x5522C55E), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 5),
              Text(
                role.toUpperCase(),
                style: TextStyle(
                  color: _roleColor(role),
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '· Exp: $expiredDate',
                style: const TextStyle(color: _C.textSub, fontSize: 10),
              ),
            ]),
          ],
        ),
      ),
      actions: [
        _AppBarIconBtn(
          icon: Icons.headset_mic_outlined,
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
        ),
        _AppBarIconBtn(
          icon: Icons.account_circle_outlined,
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate,
              sessionKey: sessionKey,
            )),
          ),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  // ── Bottom Nav ────────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: Icons.home_rounded, label: 'Home'),
      _NavItem(icon: FontAwesomeIcons.whatsapp, label: 'Bugs'),
      _NavItem(icon: Icons.campaign_rounded, label: 'Info'),
      _NavItem(icon: Icons.tune_rounded, label: 'Tools'),
      _NavItem(icon: Icons.forum_rounded, label: 'Global'),
    ];

    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(28),
          topRight: Radius.circular(28),
        ),
        border: Border.all(color: Colors.white10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.45),
            blurRadius: 25,
            spreadRadius: 1,
            offset: const Offset(0, -6),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            children: items.asMap().entries.map((e) {
              final i = e.key;
              final item = e.value;
              return Expanded(
                child: _NavButton(
                  icon: item.icon,
                  label: item.label,
                  active: _navIndex == i,
                  onTap: () => _onNavTap(i),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  // ── Drawer ────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.78,
      child: Container(
        decoration: const BoxDecoration(
          color: _C.surface,
          border: Border(right: BorderSide(color: _C.border)),
        ),
        child: Column(
          children: [
            _DrawerHeader(
              username: username,
              role: role,
              expiredDate: expiredDate,
              profileImage: _profileImage,
              videoCtrl: _menuVideoCtrl,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                children: [
                  if (role == 'reseller')
                    _DrawerItem(
                      icon: Icons.storefront_rounded,
                      label: 'Seller Page',
                      onTap: () => _onDrawerNav(1),
                    ),
                  if (role == 'admin')
                    _DrawerItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: 'Admin Page',
                      onTap: () => _onDrawerNav(2),
                    ),
                  if (role == 'owner' || role == 'moderator' || role == 'partner')
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Owner Page',
                      onTap: () => _onDrawerNav(3),
                    ),
                  _DrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role)),
                      );
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              child: _DrawerItem(
                icon: Icons.logout_rounded,
                label: 'Keluar',
                isDestructive: true,
                onTap: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (_) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── City Search Sheet ────────────────────────────────────────────────────────
class _CitySearchSheet extends StatefulWidget {
  const _CitySearchSheet();

  @override
  State<_CitySearchSheet> createState() => _CitySearchSheetState();
}

class _CitySearchSheetState extends State<_CitySearchSheet> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  bool _searching = false;
  
  List<String> get _filtered {
  if (_query.isEmpty) return _popularCities;

  final q = _query.toLowerCase();

  return _popularCities
      .where((c) => c.toLowerCase().contains(q))
      .toList();
}

  void _pick(String city) {
    Navigator.pop(context, city);
  }

  Future<void> _searchManual() async {
  final t = _searchCtrl.text.trim().toLowerCase();
  if (t.isEmpty) return;

  setState(() => _searching = true);

  try {
    final res = await http.get(
      Uri.parse(
        "https://api.ikyyxd.my.id/Info/cuaca?apikey=kyzz&query=$t",
      ),
    );

    final json = jsonDecode(res.body);

    if (json["status"] == true) {
      Navigator.pop(context, t);
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Kota tidak ditemukan")),
    );
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Gagal mengambil data")),
    );
  }

  if (mounted) {
    setState(() => _searching = false);
  }
}

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(() {
      setState(() { _query = _searchCtrl.text; });
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.78,
      decoration: const BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        children: [
          // ── Handle bar ─────────────────────────────────────────────────
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: _C.borderLit,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          const SizedBox(height: 18),

          // ── Title ───────────────────────────────────────────────────────
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Icon(Icons.location_on_rounded, color: _C.green, size: 22),
                SizedBox(width: 10),
                Text("Pilih Kota",
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── Search bar ──────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.border),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 14),
                  const Icon(Icons.search_rounded, color: _C.textSub, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      style: const TextStyle(color: _C.text, fontSize: 14),
                      decoration: const InputDecoration(
                        hintText: "Cari kota... (contoh: jogja)",
                        hintStyle: TextStyle(color: _C.textDim, fontSize: 13),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 14),
                      ),
                      onSubmitted: (_) => _searchManual(),
                    ),
                  ),
                  GestureDetector(
                    onTap: _searching ? null : _searchManual,
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: _searching
                          ? const SizedBox(
                              width: 16, height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Text("Cari",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13)),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 8),

          // ── Subtitle ────────────────────────────────────────────────────
          
          const SizedBox(height: 12),

          // ── City grid ────────────────────────────────────────────────────
          const Spacer(),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: Text(
    "Masukkan nama kota lalu tekan Cari.\nContoh: Jogja, Bandung, Surabaya.",
    textAlign: TextAlign.center,
    style: TextStyle(
      color: _C.textSub,
      fontSize: 13,
      height: 1.5,
    ),
  ),
),

const Spacer(),
        ],
      ),
    );
  }
}

// ─── Social Item ─────────────────────────────────────────────────────────────
class _SocialItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final VoidCallback onTap;

  const _SocialItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(.08),
              border: Border.all(color: color.withOpacity(.35), width: 2),
              boxShadow: [
                BoxShadow(color: color.withOpacity(.18), blurRadius: 18, spreadRadius: 2),
              ],
            ),
            child: Center(child: FaIcon(icon, color: color, size: 32)),
          ),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

// ─── Qaxer Team Card ─────────────────────────────────────────────────────────
class _QaxerTeamCard extends StatelessWidget {
  const _QaxerTeamCard({super.key});

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _C.border),
      ),
      child: Column(
        children: [
          const Text("CONNECT WITH QAXER TEAM",
              style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _SocialItem(
                icon: FontAwesomeIcons.telegram,
                color: const Color(0xFF29B6F6),
                title: "Telegram",
                onTap: () => _openUrl("https://t.me/Fionacantikwoe"),
              ),
              _SocialItem(
                icon: FontAwesomeIcons.whatsapp,
                color: const Color(0xFF25D366),
                title: "WhatsApp",
                onTap: () => _openUrl("https://wa.me/6282258568684"),
              ),
              _SocialItem(
                icon: FontAwesomeIcons.tiktok,
                color: Colors.white,
                title: "TikTok",
                onTap: () => _openUrl("https://tiktok.com/@fionacantikwoe"),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text("Selalu nantikan project terbaru dari QAXER TEAM",
              textAlign: TextAlign.center,
              style: TextStyle(color: _C.textSub, fontSize: 12)),
        ],
      ),
    );
  }
}

// ─── Stats Strip ──────────────────────────────────────────────────────────────
class _StatsStrip extends StatelessWidget {
  final int online;
  final int connections;
  const _StatsStrip({required this.online, required this.connections});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          children: [
            _StatItem(icon: Icons.people_alt_rounded, label: 'Online', value: '$online', color: _C.green),
            Container(width: 1, height: 32, color: _C.border, margin: const EdgeInsets.symmetric(horizontal: 16)),
            _StatItem(icon: Icons.wifi_rounded, label: 'Koneksi', value: '$connections', color: _C.redLight),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _C.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.green.withOpacity(0.3)),
              ),
              child: const Text('LIVE',
                  style: TextStyle(color: _C.green, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Stat Item ────────────────────────────────────────────────────────────────
class _StatItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatItem({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: color, size: 16),
      const SizedBox(width: 8),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w800)),
        Text(label, style: const TextStyle(color: _C.textSub, fontSize: 10)),
      ]),
    ]);
  }
}

// ─── Home Tabs (News / Sholat / Cuaca) ────────────────────────────────────────
class _HomeTabs extends StatelessWidget {
  final int current;
  final Function(int) onChanged;

  const _HomeTabs({required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    Widget tab(String title, int index, IconData icon) {
      final active = current == index;
      return Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () { onChanged(index); },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            height: 46,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: active ? _C.btnGrad : null,
              color: active ? null : _C.surface,
              border: Border.all(color: active ? Colors.transparent : _C.border),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 17, color: active ? Colors.white : _C.textSub),
                const SizedBox(width: 6),
                Text(title,
                    style: TextStyle(
                      color: active ? Colors.white : _C.textSub,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    )),
              ],
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          tab("News", 0, Icons.newspaper),
          tab("Sholat", 1, Icons.mosque),
          tab("Cuaca", 2, Icons.cloud),
        ],
      ),
    );
  }
}

// ─── News Card ────────────────────────────────────────────────────────────────
class _NewsCard extends StatelessWidget {
  final dynamic item;
  final bool isActive;
  const _NewsCard({required this.item, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isActive ? _C.borderLit : _C.border,
          width: isActive ? 1.5 : 1,
        ),
        boxShadow: isActive
            ? [BoxShadow(color: _C.red.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 8))]
            : [],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (item['image'] != null && item['image'].toString().isNotEmpty)
              NewsMedia(url: item['image']),
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xE6060F0A), Colors.transparent],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  stops: [0.0, 0.7],
                ),
              ),
            ),
            Positioned(
              bottom: 16, left: 16, right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _C.redMid.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: _C.redMid.withOpacity(0.3)),
                    ),
                    child: const Text('NEWS',
                        style: TextStyle(color: _C.redLight, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1)),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    item['title'] ?? 'No Title',
                    style: const TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w700, height: 1.3),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (item['desc'] != null && item['desc'].toString().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(item['desc'],
                        style: const TextStyle(color: _C.textSub, fontSize: 11, height: 1.4),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickActionModernCard extends StatelessWidget {
  final Map<String, dynamic> data;

  const _QuickActionModernCard({
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: data["onTap"],
      child: Container(
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            colors: [
              (data["color"] as Color).withOpacity(.95),
              (data["color"] as Color).withOpacity(.75),
            ],
          ),
        ),
        child: Stack(
          children: [

            Positioned(
              right: -20,
              bottom: -20,
              child: Icon(
                data["icon"],
                size: 170,
                color: Colors.white.withOpacity(.08),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.white24,
                    child: Icon(
                      data["icon"],
                      color: Colors.white,
                    ),
                  ),

                  const Spacer(),

                  Text(
                    data["title"],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 27,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Text(
                    data["subtitle"],
                    style: TextStyle(
                      color: Colors.white.withOpacity(.85),
                    ),
                  ),
                ],
              ),
            ),

            Positioned(
              right: 22,
              top: 26,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Text(
                  "Tap →",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Prayer Card ──────────────────────────────────────────────────────────────
class _PrayerCard extends StatelessWidget {
  final Map<String, dynamic>? data;
  final bool loading;
  final String city;
  final Future<void> Function(String) onChange;


const _PrayerCard({
  required this.data,
  required this.loading,
  required this.city,
  required this.onChange,
});

  @override
  Widget build(BuildContext context) {
    if (loading || data == null) {
      return Container(
        height: 320,
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(22),
        ),
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final jadwal = data!["waktu"];
    final now = TimeOfDay.now();

    final prayers = <Map<String, String>>[
      {"name": "Subuh", "time": jadwal["Fajr"]},
      {"name": "Dzuhur", "time": jadwal["Dhuhr"]},
      {"name": "Ashar", "time": jadwal["Asr"]},
      {"name": "Maghrib", "time": jadwal["Maghrib"]},
      {"name": "Isya", "time": jadwal["Isha"]},
    ];

    String nextName = prayers.first["name"]!;
    String nextTime = prayers.first["time"]!;

    for (final p in prayers) {
      final split = p["time"]!.split(":");
      final h = int.parse(split[0]);
      final m = int.parse(split[1]);

      if (h > now.hour || (h == now.hour && m > now.minute)) {
        nextName = p["name"]!;
        nextTime = p["time"]!;
        break;
      }
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.35),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(.15),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(
                  Icons.mosque_rounded,
                  color: Colors.greenAccent,
                  size: 26,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "PRAYER TIMES",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
  data!["lokasi"] ?? city,
  maxLines: 2,
  overflow: TextOverflow.ellipsis,
  style: const TextStyle(
    color: Colors.white60,
    fontSize: 12,
  ),
),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: RichText(
                  text: TextSpan(
                    children: [
                      const TextSpan(
                        text: "Next : ",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      TextSpan(
                        text: "$nextName • $nextTime",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
  horizontal: 10,
  vertical: 5,
),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.15),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Text(
  "LIVE",
  style: TextStyle(
    fontSize: 11,
    color: Colors.white,
    fontWeight: FontWeight.bold,
  ),
),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(
  horizontal: 14,
  vertical: 12,
),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: LinearGradient(
                colors: [
                  Colors.green.shade900,
                  Colors.green.shade700,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(.35),
                  blurRadius: 18,
                )
              ],
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.schedule_rounded,
                  color: Colors.amber,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    "$nextName - $nextTime",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          
          SizedBox(
  height: 132,
  child: ListView(
    scrollDirection: Axis.horizontal,
    physics: const BouncingScrollPhysics(),
    children: [

      _PrayerItem(
        title: "SUBUH",
        time: jadwal["Fajr"],
        icon: Icons.nightlight_round,
        colors: const [
          Color(0xff6C63FF),
          Color(0xff4A42D4),
        ],
      ),

      const SizedBox(width: 12),

      _PrayerItem(
        title: "DZUHUR",
        time: jadwal["Dhuhr"],
        icon: Icons.wb_sunny_rounded,
        colors: const [
          Color(0xffFFB300),
          Color(0xffF57C00),
        ],
      ),

      const SizedBox(width: 12),

      _PrayerItem(
        title: "ASHAR",
        time: jadwal["Asr"],
        icon: Icons.cloud,
        colors: const [
          Color(0xffFF7043),
          Color(0xffF4511E),
        ],
      ),

      const SizedBox(width: 12),

      _PrayerItem(
        title: "MAGHRIB",
        time: jadwal["Maghrib"],
        icon: Icons.nights_stay,
        colors: const [
          Color(0xffEC407A),
          Color(0xffC2185B),
        ],
      ),

      const SizedBox(width: 12),

      _PrayerItem(
        title: "ISYA",
        time: jadwal["Isha"],
        icon: Icons.dark_mode,
        colors: const [
          Color(0xff5C6BC0),
          Color(0xff3949AB),
        ],
      ),

      const SizedBox(width: 12),

      _PrayerItem(
        title: "SUNRISE",
        time: jadwal["Sunrise"],
        icon: Icons.wb_twilight,
        colors: const [
          Color(0xff26A69A),
          Color(0xff00897B),
        ],
      ),

    ],
  ),
),

const SizedBox(height: 22),

InkWell(
  borderRadius: BorderRadius.circular(30),
  onTap: () async {
    final controller = TextEditingController();

    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Ganti Kota"),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: "Contoh: Yogyakarta",
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(
                context,
                controller.text.trim(),
              );
            },
            child: const Text("Simpan"),
          )
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
  await onChange(result);
}
  },
  child: Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        city,
        style: const TextStyle(
          color: Colors.white70,
          fontWeight: FontWeight.w500,
        ),
      ),
      const SizedBox(width: 4),
      const Icon(
        Icons.edit_location_alt_rounded,
        color: Colors.greenAccent,
        size: 18,
      ),
    ],
  ),
),
        ],
      ),
    );
  }
}

class _PrayerItem extends StatelessWidget {
  final String title;
  final String time;
  final IconData icon;
  final List<Color> colors;

  const _PrayerItem({
    required this.title,
    required this.time,
    required this.icon,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
  width: 105,
  height: 125,
  decoration: BoxDecoration(
    gradient: LinearGradient(colors: colors),
    borderRadius: BorderRadius.circular(18),
    boxShadow: [
      BoxShadow(
        color: colors.first.withOpacity(.35),
        blurRadius: 8,
        spreadRadius: 0,
      ),
    ],
  ),
  child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Icon(
              icon,
              color: Colors.white,
              size: 20,
            ),

            const Spacer(),

            Text(
              title,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w600,
                fontSize: 10,
              ),
            ),

            const SizedBox(height: 3),

            Text(
  time,
  style: const TextStyle(
    color: Colors.white,
    fontWeight: FontWeight.bold,
    fontSize: 20,
    height: 1,
  ),
),

          ],
        ),
      ),
    );
  }
}
// ─── Weather Card ─────────────────────────────────────────────────────────────

// ─── Action Card ──────────────────────────────────────────────────────────────
class _ActionCard extends StatefulWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback onTap;

  const _ActionCard({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.trailing,
  });

  @override
  State<_ActionCard> createState() => _ActionCardState();
}

class _ActionCardState extends State<_ActionCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _pressed ? _C.card.withOpacity(0.9) : _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _pressed ? widget.iconColor.withOpacity(0.3) : _C.border),
            boxShadow: _pressed
                ? [BoxShadow(color: widget.iconColor.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4))]
                : [],
          ),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: widget.iconBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: widget.iconColor.withOpacity(0.2)),
              ),
              child: Icon(widget.icon, color: widget.iconColor, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.title, style: const TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(widget.subtitle, style: const TextStyle(color: _C.textSub, fontSize: 11)),
              ],
            )),
            if (widget.trailing != null) ...[
              const SizedBox(width: 10),
              widget.trailing!,
            ],
          ]),
        ),
      ),
    );
  }
}

// ─── Dashboard Profile Card ───────────────────────────────────────────────────
class DashboardProfileCard extends StatelessWidget {
  final String username;
  final String role;
  final String expired;
  final File? profileImage;

  const DashboardProfileCard({
    super.key,
    required this.username,
    required this.role,
    required this.expired,
    this.profileImage,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 175,
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(.10)),
        boxShadow: [
          BoxShadow(color: _C.green.withOpacity(.08), blurRadius: 20),
        ],
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: CustomPaint(painter: HoneycombPainter()),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 68, height: 68,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [BoxShadow(color: _C.green.withOpacity(.20), blurRadius: 14)],
                      ),
                      child: ClipOval(
                        child: profileImage != null
                            ? Image.file(profileImage!, fit: BoxFit.cover)
                            : Container(
                                color: _C.surface,
                                child: const Icon(Icons.person, color: Colors.white, size: 34),
                              ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Selamat Datang", style: TextStyle(color: _C.textSub, fontSize: 12)),
                          const SizedBox(height: 3),
                          Text(
                            username.toUpperCase(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: _C.text, fontWeight: FontWeight.w900, fontSize: 21, letterSpacing: 1),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              color: _C.green.withOpacity(.12),
                              borderRadius: BorderRadius.circular(25),
                              border: Border.all(color: _C.green),
                            ),
                            child: Text(role.toUpperCase(), style: const TextStyle(color: _C.green, fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 88,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.04),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Column(
                        children: [
                          const Icon(Icons.schedule_rounded, color: Colors.white70, size: 18),
                          const SizedBox(height: 5),
                          const Text("EXPIRES", style: TextStyle(color: _C.textSub, fontSize: 9)),
                          const SizedBox(height: 4),
                          Text(expired.toUpperCase(), textAlign: TextAlign.center, style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 13)),
                        ],
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Container(
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.03),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: const Center(
                    child: Text("● Powered by QAXER TEAM ●",
                        style: TextStyle(color: _C.text, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: .5)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Honeycomb Painter ────────────────────────────────────────────────────────
class HoneycombPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(.07)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    const r = 24.0;
    final h = math.sqrt(3) * r;

    for (double y = 0; y < size.height + h; y += h) {
      for (double x = 0; x < size.width + r; x += r * 3) {
        final dx = ((y ~/ h).isEven) ? x : x + r * 1.5;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final angle = (60 * i - 30) * math.pi / 180;
          final px = dx + r * math.cos(angle);
          final py = y + r * math.sin(angle);
          if (i == 0) {
            path.moveTo(px, py);
          } else {
            path.lineTo(px, py);
          }
        }
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class _DoaCard extends StatelessWidget {
final Map<String, dynamic>? data;
final bool loading;

const _DoaCard({
required this.data,
required this.loading,
});

void _copy(BuildContext context, String text) {
Clipboard.setData(ClipboardData(text: text));

ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(
content: Text("Copied"),
duration: Duration(seconds: 1),
),
);
}
void _showDoaDetail(BuildContext context) {
showGeneralDialog(
context: context,
barrierDismissible: true,
barrierLabel: "",
barrierColor: Colors.black54,
transitionDuration: const Duration(milliseconds: 280),
pageBuilder: (_, __, ___) {
return SafeArea(
child: Center(
child: Material(
color: Colors.transparent,
child: Container(
width: double.infinity,
height: MediaQuery.of(context).size.height * .92,
margin: const EdgeInsets.all(12),
decoration: BoxDecoration(
color: const Color(0xff183426),
borderRadius: BorderRadius.circular(24),
),
child: Column(
children: [

Container(  
                padding: const EdgeInsets.all(16),  
                decoration: const BoxDecoration(  
                  color: Color(0xff1d6f4d),  
                  borderRadius: BorderRadius.vertical(  
                    top: Radius.circular(24),  
                  ),  
                ),  
                child: Row(  
                  children: [  

                    const Expanded(  
                      child: Text(  
                        "DOA OF THE DAY",  
                        style: TextStyle(  
                          color: Colors.white,  
                          fontWeight: FontWeight.bold,  
                          fontSize: 18,  
                        ),  
                      ),  
                    ),  

                    IconButton(  
                      onPressed: () =>  
                          Navigator.pop(context),  
                      icon: const Icon(  
                        Icons.close,  
                        color: Colors.white,  
                      ),  
                    ),  

                  ],  
                ),  
              ),  

              Expanded(  
                child: SingleChildScrollView(  
                  padding: const EdgeInsets.all(18),  
                  child: Column(  
                    crossAxisAlignment:  
                        CrossAxisAlignment.start,  
                    children: [  

                      Text(  
                        data!["doa"],  
                        style: const TextStyle(  
                          color: Colors.white,  
                          fontSize: 22,  
                          fontWeight: FontWeight.bold,  
                        ),  
                      ),  

                      const SizedBox(height: 20),  

                      Container(  
                        width: double.infinity,  
                        padding:  
                            const EdgeInsets.all(18),  
                        decoration: BoxDecoration(  
                          color:  
                              const Color(0xff12271d),  
                          borderRadius:  
                              BorderRadius.circular(18),  
                        ),  
                        child: Column(  
                          crossAxisAlignment:  
                              CrossAxisAlignment.end,  
                          children: [  

                            Text(  
                              data!["ayat"],  
                              textAlign:  
                                  TextAlign.right,  
                              style: const TextStyle(  
                                color: Colors.white,  
                                fontSize: 26,  
                                height: 2,  
                                fontFamily: "Amiri",  
                              ),  
                            ),  

                            const SizedBox(height: 15),  

                            ElevatedButton.icon(  
                              onPressed: () =>  
                                  _copy(  
                                    context,  
                                    data!["ayat"],  
                                  ),  
                              icon:  
                                  const Icon(Icons.copy),  
                              label: const Text(  
                                  "Copy Ayat"),  
                            ),  

                          ],  
                        ),  
                      ),  

                      const SizedBox(height: 20),  

                      const Text(  
                        "Artinya",  
                        style: TextStyle(  
                          color: Colors.white,  
                          fontSize: 17,  
                          fontWeight: FontWeight.bold,  
                        ),  
                      ),  

                      const SizedBox(height: 10),  

                      Text(  
                        data!["artinya"],  
                        style: const TextStyle(  
                          color: Colors.white70,  
                          fontSize: 16,  
                          height: 1.8,  
                        ),  
                      ),  

                      const SizedBox(height: 15),  

                      ElevatedButton.icon(  
                        onPressed: () =>  
                            _copy(  
                              context,  
                              data!["artinya"],  
                            ),  
                        icon:  
                            const Icon(Icons.copy),  
                        label:  
                            const Text("Copy Arti"),  
                      ),  

                    ],  
                  ),  
                ),  
              ),  

            ],  
          ),  
        ),  
      ),  
    ),  
  );  
},  
transitionBuilder:  
    (context, animation, secondaryAnimation, child) {  
  return FadeTransition(  
    opacity: animation,  
    child: ScaleTransition(  
      scale: Tween(  
        begin: .94,  
        end: 1.0,  
      ).animate(  
        CurvedAnimation(  
          parent: animation,  
          curve: Curves.easeOut,  
        ),  
      ),  
      child: child,  
    ),  
  );  
},

);
}
  
  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Container(
        height: 220,
        decoration: BoxDecoration(
          color: const Color(0xff183426),
          borderRadius: BorderRadius.circular(22),
        ),
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (data == null) return const SizedBox();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xff183426),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: Colors.green.withOpacity(.18),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.green.withOpacity(.12),
            blurRadius: 18,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              Container(
                width: 44,
height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xff1d6f4d),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(
                  Icons.menu_book_rounded,
                  color: Colors.white,
                ),
              ),

              const SizedBox(width: 14),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    const Text(
                      "DOA OF THE DAY",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        letterSpacing: 1,
                      ),
                    ),

                    const SizedBox(height: 3),

                    Text(
  data!["doa"],
  maxLines: 1,
  overflow: TextOverflow.ellipsis,
  style: const TextStyle(
    color: Colors.white70,
    fontSize: 12,
  ),
)

                  ],
                ),
              )

            ],
          ),

          const SizedBox(height: 18),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xff12271d),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
  data!["ayat"],
  textAlign: TextAlign.right,
  maxLines: 3,
  overflow: TextOverflow.ellipsis,
  style: const TextStyle(
    color: Colors.white,
    fontSize: 18,
    height: 1.6,
    fontFamily: "Amiri",
  ),
),
          ),

          const SizedBox(height: 14),

          Text(
  data!["artinya"],
  maxLines: 2,
  overflow: TextOverflow.ellipsis,
  style: const TextStyle(
    color: Colors.white70,
    fontSize: 14,
    height: 1.4,
    fontStyle: FontStyle.italic,
  ),
),

          const SizedBox(height: 12),

          Container(
  padding: const EdgeInsets.symmetric(
    horizontal: 14,
    vertical: 7,
  ),
  decoration: BoxDecoration(
    color: const Color(0xff1d6f4d),
    borderRadius: BorderRadius.circular(12),
  ),
  child: Text(
    "Doa #${data!["id"]}",
    style: const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w600,
    ),
  ),
),

const SizedBox(height: 16),

InkWell(
  onTap: () => _showDoaDetail(context),
  borderRadius: BorderRadius.circular(14),
  child: Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(vertical: 10),
    decoration: BoxDecoration(
      color: const Color(0xff1d6f4d),
      borderRadius: BorderRadius.circular(14),
    ),
    child: const Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          Icons.open_in_full_rounded,
          color: Colors.white,
        ),
        SizedBox(width: 8),
        Text(
          "Tap to Full",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    ),
  ),
),
          

        ],
      ),
    );
  }
}

// ─── Drawer Header ────────────────────────────────────────────────────────────
class _DrawerHeader extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  final File? profileImage;
  final VideoPlayerController? videoCtrl;

  const _DrawerHeader({
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.profileImage,
    required this.videoCtrl,
  });

  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fade  = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    _c.forward();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(widget.role);
    return Container(
      height: 240,
      clipBehavior: Clip.hardEdge,
      decoration: const BoxDecoration(
        color: _C.card,
        border: Border(bottom: BorderSide(color: _C.border)),
      ),
      child: Stack(
        children: [
          if (widget.videoCtrl != null && widget.videoCtrl!.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width:  widget.videoCtrl!.value.size.width,
                  height: widget.videoCtrl!.value.size.height,
                  child:  VideoPlayer(widget.videoCtrl!),
                ),
              ),
            ),
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0x33060F0A), Color(0xE6060F0A)],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          Container(
                            width: 78, height: 78,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: rColor, width: 2.5),
                              boxShadow: [BoxShadow(color: rColor.withOpacity(0.4), blurRadius: 18)],
                            ),
                            child: ClipOval(
                              child: widget.profileImage != null
                                  ? Image.file(widget.profileImage!, fit: BoxFit.cover)
                                  : Container(
                                      color: _C.surface,
                                      child: Icon(_roleIcon(widget.role), size: 36, color: rColor.withOpacity(0.9)),
                                    ),
                            ),
                          ),
                          Positioned(
                            right: 0, bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: rColor,
                                shape: BoxShape.circle,
                                border: Border.all(color: _C.card, width: 2),
                              ),
                              child: Icon(_roleIcon(widget.role), color: Colors.white, size: 12),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(widget.username, style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: rColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: rColor.withOpacity(0.3)),
                        ),
                        child: Text(widget.role.toUpperCase(), style: TextStyle(color: rColor, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
                      ),
                      const SizedBox(height: 6),
                      Text('Exp: ${widget.expiredDate}', style: const TextStyle(color: _C.textSub, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Drawer Item ──────────────────────────────────────────────────────────────
class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isDestructive;
  final VoidCallback onTap;
  const _DrawerItem({required this.icon, required this.label, required this.onTap, this.isDestructive = false});

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? const Color(0xFFEF4444) : _C.text;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            child: Row(children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 14),
              Text(label, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
      ),
    );
  }
}

// ─── Menu Button ──────────────────────────────────────────────────────────────
class _MenuBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.border),
        ),
        child: const Icon(Icons.menu_rounded, color: _C.text, size: 20),
      ),
    );
  }
}

// ─── AppBar Icon Button ───────────────────────────────────────────────────────
class _AppBarIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _AppBarIconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.border),
        ),
        child: Icon(icon, color: _C.text, size: 18),
      ),
    );
  }
}

// ─── Nav Item ─────────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ─── Nav Button ──────────────────────────────────────────────────────────────
class _NavButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _NavButton({required this.icon, required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: active ? _C.redMid.withOpacity(0.15) : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, size: 20, color: active ? _C.redLight : _C.textDim),
          ),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: active ? _C.redLight : _C.textDim, fontSize: 10, fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
        ],
      ),
    );
  }
}

// ─── Gradient Button ──────────────────────────────────────────────────────────
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false});

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          padding: widget.fullWidth ? null : const EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(13),
            boxShadow: _down ? [] : [
              BoxShadow(color: _C.redMid.withOpacity(0.3), blurRadius: 14, offset: const Offset(0, 4)),
            ],
          ),
          child: Center(child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14))),
        ),
      ),
    );
  }
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.border.withOpacity(0.22)..strokeWidth = 0.5;
    const step = 38.0;
    for (double x = 0; x < size.width; x += step)
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    for (double y = 0; y < size.height; y += step)
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.red.withOpacity(0.10 + math.sin(t * math.pi * 2) * 0.03),
        Colors.transparent,
      ], radius: 0.9).createShader(
          Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

// ─── News Media ───────────────────────────────────────────────────────────────
class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({required this.url});

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => const SizedBox(),
      loadingBuilder: (_, child, loading) {
        if (loading == null) return child;
        return const Center(child: CircularProgressIndicator(color: _C.redLight, strokeWidth: 2));
      },
    );
  }
}