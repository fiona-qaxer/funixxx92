package com.qaxercrash.fiona;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
